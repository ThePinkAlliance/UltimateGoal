package org.firstinspires.ftc.teamcode.drive.Pinkopmode;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.path.Path;
import com.acmerobotics.roadrunner.path.PathBuilder;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryGenerator;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.drive.PinkRobot.SubSystems.Conveyor;
import org.firstinspires.ftc.teamcode.drive.PinkRobot.SubSystems.PinkSubsystem;
import org.firstinspires.ftc.teamcode.drive.PinkRobot.SubSystems.Collector;
import org.firstinspires.ftc.teamcode.drive.PinkRobot.SubSystems.Wobble;
import org.firstinspires.ftc.teamcode.drive.PinkRobot.SubSystems.Shooter;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@Config
@Autonomous(name = "PinkAuto", group = "Auto")
public class PinkAuto extends LinearOpMode {

    // Ring Mode - will be used for trajectory and positioning
    public enum RingMode { NONE, SINGLE, QUAD }
    public enum StartingPosition { SP_CORNER_RED, SP_MIDDLE_RED, SP_CORNER_BLUE, SP_MIDDLE_BLUE }
    public enum AutonomousSTEPS {
        AS_DROP_FIRST_WOBBLE_DRIVE,
        AS_DROP_FIRST_WOBBLE_DROP,
        AS_DROP_FIRST_WOBBLE_RELEASE,
        AS_SHOOT_FIRST_3_HIGH_DRIVE,
        AS_SHOOT_FIRST_3_SHOOT,
        AS_SHOOT_FIRST_3_POWER,
        AS_COLLECT_CENTER_WOBBLE,
        AS_COLLECT_CENTER_GRIP,
        AS_COLLECT_CENTER_LIFT,
        AS_COLLECT_SINGLE_RING_DRIVE,
        AS_SHOOT_SINGLE_FROM_STACK,
        AS_DROP_SECOND_WOBBLE_DRIVE,
        AS_DROP_SECOND_WOBBLE_DROP,
        AS_DROP_SECOND_WOBBLE_RELEASE,
        AS_PARK,
        AS_AUTONOMOUS_END
    }

    // Starting Ring mode... None, will be adjusted later
    public static RingMode ringFound = RingMode.SINGLE;
    public static StartingPosition startingFieldPosition = StartingPosition.SP_CORNER_RED;
    public static AutonomousSTEPS autoStep = AutonomousSTEPS.AS_DROP_FIRST_WOBBLE_DRIVE;

    // Field Start Position Corner
    public static double RED_CORNER_START_X = -62.5;
    public static double RED_CORNER_START_Y = -48.8;
    public static double RED_CORNER_START_HEADING = 180; // Backward
    public static double RED_CORNER_START_TAN_START = -10;

    // RC0 = Red Corner 0 Ring... RC1, RCQ = Red Corner Quad Ring
    public static double RC0_DROP_FIRST_WOB_X = 6;
    public static double RC0_DROP_FIRST_WOB_Y = -54;
    public static double RC0_DROP_FIRST_WOB_HEADING = 110;
    public static double RC0_DROP_FIRST_WOB_TAN_END = 10; // Spline Tangent where this segment end
    public static double RC0_DROP_FIRST_WOB_TAN_BEGIN = 75; // Spline Tangent where this segment begins o the next position

    public static double RC1_DROP_FIRST_WOB_X = 25;
    public static double RC1_DROP_FIRST_WOB_Y = -36;
    public static double RC1_DROP_FIRST_WOB_HEADING = 145;
    public static double RC1_DROP_FIRST_WOB_TAN_END = 45; // Spline Tangent where this segment end
    public static double RC1_DROP_FIRST_WOB_TAN_BEGIN = 190; // Spline Tangent where this segment begins o the next position

    public static double RC_SHOOT_HIGH_WOB_X = -2;
    public static double RC_SHOOT_HIGH_WOB_Y = -36;
    public static double RC_SHOOT_HIGH_WOB_HEADING = 0;

    public static double RC0_SHOOT_HIGH_WOB_TAN_END = 15;
    public static double RC1_SHOOT_HIGH_WOB_TAN_END = 180; // Different Tangent for second pos but same x/y/heading

    public static double RC_SHOOT_HIGH_WOB_TAN_BEGIN = 90;

    public static double RC_COLLECT_MID_WOB_X = -38;
    public static double RC_COLLECT_MID_WOB_Y = -22;
    public static double RC_COLLECT_MID_WOB_HEADING = 0;
    public static double RC_COLLECT_MID_WOB_TAN_END = 180;
    public static double RC0_COLLECT_MID_WOB_TAN_BEGIN = 25;
    public static double RC1_COLLECT_MID_WOB_TAN_BEGIN = -75; // Different Tangent to next position since now going to collect single ring

    public static double RC1_SHOOT_SINGLE_STACK_X = 0;//RC_SHOOT_HIGH_WOB_X;
    public static double RC1_SHOOT_SINGLE_STACK_Y = RC_SHOOT_HIGH_WOB_Y;
    public static double RC1_SHOOT_SINGLE_STACK_HEADING = RC_SHOOT_HIGH_WOB_HEADING;
    public static double RC1_SHOOT_SINGLE_STACK_TAN_END = 25;
    public static double RC1_SHOOT_SINGLE_STACK_TAN_BEGIN = 0;

    public static double RC0_DROP_SECOND_WOB_X = 4;
    public static double RC0_DROP_SECOND_WOB_Y = -45;
    public static double RC0_DROP_SECOND_WOB_HEADING = 90;
    public static double RC0_DROP_SECOND_WOB_TAN_END = -90;
    public static double RC0_DROP_SECOND_WOB_TAN_BEGIN = -25;

    public static double RC1_DROP_SECOND_WOB_X = 4;
    public static double RC1_DROP_SECOND_WOB_Y = -45;
    public static double RC1_DROP_SECOND_WOB_HEADING = 90;
    public static double RC1_DROP_SECOND_WOB_TAN_END = -90;
    public static double RC1_DROP_SECOND_WOB_TAN_BEGIN = -75;






    public static double RC0_SECOND_PARK_X = 5;
    public static double RC0_SECOND_PARK_Y = -36;
    public static double RC0_SECOND_PARK_HEADING = 0;
    public static double RC0_SECOND_PARK_TAN_END = 15;

    // Reused Trajectory Variables
    public static double start_x = 0, start_y = 0, start_angle = 0, start_tangent_angle = 0;
    public static double end_x = 0, end_y = 0, end_angle = 0, end_tangent_angle = 0;

    // Timestamp that is reset between each autonomous step
    private ElapsedTime runtime = new ElapsedTime();
    public static double markedTime = 0;

    public static SampleMecanumDrive drive = null;

    @Override
    public void runOpMode() throws InterruptedException {
        // This is the base robot class... all motors and encoders are initialized from this
        drive = new SampleMecanumDrive(hardwareMap);

        autoStep = AutonomousSTEPS.AS_DROP_FIRST_WOBBLE_DRIVE;
        markedTime = runtime.milliseconds();

        // Set all servos to their default positions
        Collector.collector_drop();
        Wobble.wobble_grip();
        Wobble.wobble_arm_up();
        PinkSubsystem.set_servo_positions();

        // Wait for Start Button (Phone) to be pressed
        waitForStart();

        Trajectory trajectory = null;
        AutonomousSTEPS lastAutoStep = AutonomousSTEPS.AS_DROP_FIRST_WOBBLE_DRIVE;
        // Loop as long as auto is Active or stopped is pressed
        while (opModeIsActive() && !isStopRequested()) {
            switch(autoStep)
            {
                case AS_DROP_FIRST_WOBBLE_DRIVE:
                    switch(startingFieldPosition)
                    {
                        case SP_CORNER_RED:
                            // This is the starting position during auto
                            drive.setPoseEstimate(new Pose2d(RED_CORNER_START_X, RED_CORNER_START_Y, Math.toRadians(RED_CORNER_START_HEADING)));

                            switch(ringFound)
                            {
                                case NONE:
                                    trajectory = BuildSimpleTrajectory(RED_CORNER_START_X, RED_CORNER_START_Y, RED_CORNER_START_HEADING, RED_CORNER_START_TAN_START,
                                            RC0_DROP_FIRST_WOB_X, RC0_DROP_FIRST_WOB_Y, RC0_DROP_FIRST_WOB_HEADING, RC0_DROP_FIRST_WOB_TAN_END);
                                    break; // NONE
                                case SINGLE:
                                    trajectory = BuildSimpleTrajectory(RED_CORNER_START_X, RED_CORNER_START_Y, RED_CORNER_START_HEADING, RED_CORNER_START_TAN_START,
                                            RC1_DROP_FIRST_WOB_X, RC1_DROP_FIRST_WOB_Y, RC1_DROP_FIRST_WOB_HEADING, RC1_DROP_FIRST_WOB_TAN_END);
                                    break; // SINGLE
                                case QUAD:
                                    break; // QUAD
                            }
                            break; // SP_CORNER_RED:
                        case SP_MIDDLE_RED:
                            break; // SP_CENTER_RED
                        case SP_CORNER_BLUE:
                            break; // SP_CORNER_BLUE
                        case SP_MIDDLE_BLUE:
                            break; // SP_CENTER_BLUE
                    } //  switch(startingFieldPosition)

                    autoStep = AutonomousSTEPS.AS_DROP_FIRST_WOBBLE_DROP;
                    break; // AS_DROP_FIRST_WOBBLE_DRIVE:

                case AS_DROP_FIRST_WOBBLE_DROP:
                    Wobble.wobble_arm_down();
                    autoStep = AutonomousSTEPS.AS_DROP_FIRST_WOBBLE_RELEASE;
                    break; // AS_DROP_FIRST_WOBBLE_DROP

                case AS_DROP_FIRST_WOBBLE_RELEASE:
                    if(runtime.milliseconds() - markedTime > 350) {
                        Wobble.wobble_ungrip();
                        autoStep = AutonomousSTEPS.AS_SHOOT_FIRST_3_HIGH_DRIVE;
                    }
                    break; // AS_DROP_FIRST_WOBBLE_RELEASE

                case AS_SHOOT_FIRST_3_HIGH_DRIVE:
                    if(runtime.milliseconds() - markedTime > 100) {
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        trajectory = BuildSimpleTrajectory(RC0_DROP_FIRST_WOB_X, RC0_DROP_FIRST_WOB_Y, RC0_DROP_FIRST_WOB_HEADING, RC0_DROP_FIRST_WOB_TAN_BEGIN,
                                                RC_SHOOT_HIGH_WOB_X, RC_SHOOT_HIGH_WOB_Y, RC_SHOOT_HIGH_WOB_HEADING, RC0_SHOOT_HIGH_WOB_TAN_END);
                                        break; // NONE
                                    case SINGLE:
                                        trajectory = BuildSimpleTrajectory(RC1_DROP_FIRST_WOB_X, RC1_DROP_FIRST_WOB_Y, RC1_DROP_FIRST_WOB_HEADING, RC1_DROP_FIRST_WOB_TAN_BEGIN,
                                                RC_SHOOT_HIGH_WOB_X, RC_SHOOT_HIGH_WOB_Y, RC_SHOOT_HIGH_WOB_HEADING, RC1_SHOOT_HIGH_WOB_TAN_END);
                                        break; // SINGLE
                                    case QUAD:
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)

                        autoStep = AutonomousSTEPS.AS_SHOOT_FIRST_3_SHOOT;
                    }
                    break; // AS_DROP_FIRST_WOBBLE_DRIVE:

                case AS_SHOOT_FIRST_3_SHOOT:
                    autoStep = AutonomousSTEPS.AS_COLLECT_CENTER_WOBBLE;

                    break; // AS_SHOOT_FIRST_3_SHOOT

                case AS_COLLECT_CENTER_WOBBLE:
                    if(runtime.milliseconds() - markedTime > 100) {
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED: // Always start from shoot, so no need for multiple positions
                                trajectory = BuildSimpleTrajectory(RC_SHOOT_HIGH_WOB_X, RC_SHOOT_HIGH_WOB_Y, RC_SHOOT_HIGH_WOB_HEADING, RC_SHOOT_HIGH_WOB_TAN_BEGIN,
                                        RC_COLLECT_MID_WOB_X, RC_COLLECT_MID_WOB_Y, RC_COLLECT_MID_WOB_HEADING, RC_COLLECT_MID_WOB_TAN_END);
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)

                        autoStep = AutonomousSTEPS.AS_COLLECT_CENTER_GRIP;
                    }
                    break; // AS_COLLECT_CENTER_WOBBLE:

                case AS_COLLECT_CENTER_GRIP:
                    Wobble.wobble_grip();
                    autoStep = AutonomousSTEPS.AS_COLLECT_CENTER_LIFT;
                    break; // AS_DROP_FIRST_WOBBLE_DROP

                case AS_COLLECT_CENTER_LIFT:
                    if(runtime.milliseconds() - markedTime > 450) {
                        Wobble.wobble_arm_up();
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        autoStep = AutonomousSTEPS.AS_DROP_SECOND_WOBBLE_DRIVE;
                                        break; // NONE
                                    case SINGLE:
                                        autoStep = AutonomousSTEPS.AS_COLLECT_SINGLE_RING_DRIVE;
                                        break; // SINGLE
                                    case QUAD:
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)


                    }
                    break; // AS_DROP_FIRST_WOBBLE_RELEASE

                case AS_COLLECT_SINGLE_RING_DRIVE:
                    if(runtime.milliseconds() - markedTime > 200) {
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        break; // NONE
                                    case SINGLE:
                                        // Get ready to collect the ring on the trajectory to shoot
                                        Conveyor.flap_close();
                                        Collector.collect();
                                        Conveyor.collect(1);
                                        Shooter.shootPower(0.8); // Start spinning up the shooter so it is ready to shoot on the next step.
                                        drive.turn(Math.toRadians(-45)); // Turn -45 degrees to face the ring
                                        /*trajectory = BuildSimpleTrajectory(RC_COLLECT_MID_WOB_X, RC_COLLECT_MID_WOB_Y, -5, 0,
                                                RC_COLLECT_MID_WOB_X, -24, -45, 0);
                                        drive.followTrajectory(trajectory);
                                        */
                                        trajectory = BuildSimpleTrajectory(RC_COLLECT_MID_WOB_X, RC_COLLECT_MID_WOB_Y, -45, RC1_COLLECT_MID_WOB_TAN_BEGIN,
                                                RC1_SHOOT_SINGLE_STACK_X, RC1_SHOOT_SINGLE_STACK_Y, 6, RC1_SHOOT_SINGLE_STACK_TAN_END);
                                        break; // SINGLE
                                    case QUAD:
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)
                        autoStep = AutonomousSTEPS.AS_SHOOT_SINGLE_FROM_STACK;
                    }
                    break;

                case AS_SHOOT_SINGLE_FROM_STACK:
                    if(runtime.milliseconds() - markedTime < 3000) { // run this for enough time to shoot
                        Conveyor.collect(1);
                        Shooter.shoot_by_pd(PinkSubsystem.robot.shoot2.getVelocity(), 1550);
                        double currentShooterVelocity = PinkSubsystem.robot.shoot2.getVelocity();

                        if (currentShooterVelocity > 1450 && currentShooterVelocity < 1620) {
                            Conveyor.flap_open();
                        }
                    } else {
                        autoStep = AutonomousSTEPS.AS_AUTONOMOUS_END;
                    }
                    break;

                case AS_DROP_SECOND_WOBBLE_DRIVE:
                    if(runtime.milliseconds() - markedTime > 200) {
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        trajectory = BuildSimpleTrajectory(RC_COLLECT_MID_WOB_X, RC_COLLECT_MID_WOB_Y, RC_COLLECT_MID_WOB_HEADING, RC0_COLLECT_MID_WOB_TAN_BEGIN,
                                                RC0_DROP_SECOND_WOB_X, RC0_DROP_SECOND_WOB_Y, RC0_DROP_SECOND_WOB_HEADING, RC0_DROP_SECOND_WOB_TAN_END);

                                        autoStep = AutonomousSTEPS.AS_DROP_SECOND_WOBBLE_DROP;
                                        break; // NONE
                                    case SINGLE:
                                        break; // SINGLE
                                    case QUAD:
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)

                        autoStep = AutonomousSTEPS.AS_DROP_SECOND_WOBBLE_DROP;
                    }
                    break; // AS_COLLECT_CENTER_WOBBLE:

                case AS_DROP_SECOND_WOBBLE_DROP:
                    Wobble.wobble_arm_down();
                    autoStep = AutonomousSTEPS.AS_DROP_SECOND_WOBBLE_RELEASE;
                    break; // AS_DROP_FIRST_WOBBLE_DROP

                case AS_DROP_SECOND_WOBBLE_RELEASE:
                    if(runtime.milliseconds() - markedTime > 350) {
                        Wobble.wobble_ungrip();
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        autoStep = AutonomousSTEPS.AS_PARK;
                                        break; // NONE
                                    case SINGLE:
                                        autoStep = AutonomousSTEPS.AS_PARK;
                                        break; // SINGLE
                                    case QUAD:
                                        autoStep = AutonomousSTEPS.AS_PARK;
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)

                    }
                    break; // AS_DROP_FIRST_WOBBLE_RELEASE

                case AS_PARK:
                    if(runtime.milliseconds() - markedTime > 300) {
                        switch (startingFieldPosition) {
                            case SP_CORNER_RED:
                                switch (ringFound) {
                                    case NONE:
                                        trajectory = BuildSimpleTrajectory(RC0_DROP_SECOND_WOB_X, RC0_DROP_SECOND_WOB_Y, RC0_DROP_SECOND_WOB_HEADING, RC0_DROP_SECOND_WOB_TAN_BEGIN,
                                                RC0_SECOND_PARK_X, RC0_SECOND_PARK_Y, RC0_SECOND_PARK_HEADING, RC0_SECOND_PARK_TAN_END);
                                        break; // NONE
                                    case SINGLE:
                                        break; // SINGLE
                                    case QUAD:
                                        break; // QUAD
                                }
                                break; // SP_CORNER_RED:
                            case SP_MIDDLE_RED:
                                break; // SP_CENTER_RED
                            case SP_CORNER_BLUE:
                                break; // SP_CORNER_BLUE
                            case SP_MIDDLE_BLUE:
                                break; // SP_CENTER_BLUE
                        } //  switch(startingFieldPosition)

                        autoStep = AutonomousSTEPS.AS_AUTONOMOUS_END;
                    }
                    break; // AS_COLLECT_CENTER_WOBBLE:

                case AS_AUTONOMOUS_END:

                    break; // AS_AUTONOMOUS_END
            } // switch(autoStep)

            // Update Servo Values
            PinkSubsystem.set_servo_positions();
            // Update Motor power
            PinkSubsystem.set_motor_powers();

            // If there is a trajectory define... drive it
            if(trajectory != null)
            {
                drive.followTrajectory(trajectory);
                // Reset trajectory to null once driven
                trajectory = null;
            }



            // Reset MarkedTime every time we jump to another step
            if(lastAutoStep != autoStep) {
                markedTime = runtime.milliseconds();
                lastAutoStep = autoStep;
            }

            // Stop the while loop if Autonomous is completed
            if(autoStep == AutonomousSTEPS.AS_AUTONOMOUS_END)
            {
                break;
            }

        } // while opmode is active and stop not requested
    } // Void runopmode()

    // Generates a quick and dirty trajectory based on a begin and an end position
    public static Trajectory BuildSimpleTrajectory(double beginX, double beginY, double beginHeadingAngle,  double beginTangentAngle,
                                                   double endX, double endY, double endHeadingAngle,  double endTangentAngle)
    {
        Trajectory newTractory =
                drive.trajectoryBuilder(new Pose2d(beginX, beginY, Math.toRadians(beginHeadingAngle)), Math.toRadians(beginTangentAngle))
                        .splineToLinearHeading(new Pose2d(endX, endY, Math.toRadians(endHeadingAngle)), Math.toRadians(endTangentAngle))
                        .build();

        return newTractory;
    }
}